package main;

import canvas.Control;

public class Main {
    public static void main(String[] args) {
        new Control().play();
    }
}
