package main;

import control.Control;

public class Main {
    public static void main(String[] args) {
        new Control().init();
    }
}
